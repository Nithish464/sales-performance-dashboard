-- ============================================================
-- QUANTACUS GOOGLE ADS DATA STRATEGY CASE STUDY
-- Project: quantacusinterviewproject
-- Dataset: interview_ayad
--
-- Execution note:
--   Run each numbered query section separately in BigQuery. Each section is standalone.
--   This avoids repeated DECLARE names across independent query sections.
--
-- Purpose:
--   Validate the campaign-level baseline, diagnose channel performance,
--   compare product-level coverage, and identify data limitations.
--
-- Important:
--   1. Do not combine CampaignBasicStats and ShoppingProductStats totals.
--   2. The 7-day attribution buffer is an analytical assumption.
--   3. Reported ROAS 3.4 could not be independently reconciled because
--      its original filters, attribution settings, and definition were
--      not provided.
--   4. All monetary values below are treated as INR based on the case
--      analysis. Cost micros are converted using / 1,000,000.
-- ============================================================


-- ============================================================
-- QUERY 01: TABLE INVENTORY
-- ============================================================
SELECT
  table_name
FROM `quantacusinterviewproject.interview_ayad.INFORMATION_SCHEMA.TABLES`
ORDER BY table_name;


-- ============================================================
-- QUERY 02: CAMPAIGN STATS DATE RANGE
-- ============================================================
SELECT
  MIN(segments_date) AS first_reporting_date,
  MAX(segments_date) AS last_reporting_date,
  DATE_DIFF(MAX(segments_date), MIN(segments_date), DAY) + 1
    AS reporting_days,
  COUNT(*) AS total_rows
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`;


-- ============================================================
-- QUERY 03: FULL AVAILABLE DATASET PERFORMANCE
-- ============================================================
SELECT
  MIN(segments_date) AS analysis_start_date,
  MAX(segments_date) AS analysis_end_date,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`;


-- ============================================================
-- QUERY 04: MONTHLY PERFORMANCE
-- ============================================================
SELECT
  DATE_TRUNC(segments_date, MONTH) AS reporting_month,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
GROUP BY reporting_month
ORDER BY reporting_month;


-- ============================================================
-- QUERY 05: SELECTED BASELINE VALIDATION
-- Baseline: 02-Aug-2026 through 31-Aug-2026
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

SELECT
  start_date AS analysis_start_date,
  end_date AS analysis_end_date,
  COUNT(*) AS total_rows,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
WHERE segments_date BETWEEN start_date AND end_date;


-- ============================================================
-- QUERY 06: LATEST COMPLETE 30-DAY BASELINE WITH BUFFER
-- The 7-day buffer is an analytical assumption.
-- ============================================================
DECLARE latest_reporting_date DATE DEFAULT (
  SELECT MAX(segments_date)
  FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
);

DECLARE analysis_end_date DATE DEFAULT DATE_SUB(
  latest_reporting_date,
  INTERVAL 7 DAY
);

DECLARE analysis_start_date DATE DEFAULT DATE_SUB(
  analysis_end_date,
  INTERVAL 29 DAY
);

SELECT
  analysis_start_date,
  analysis_end_date,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS recalculated_roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
WHERE segments_date BETWEEN analysis_start_date AND analysis_end_date;


-- ============================================================
-- QUERY 07: RECENT DAILY PERFORMANCE
-- Useful for identifying incomplete or volatile recent dates.
-- ============================================================
DECLARE recent_start_date DATE DEFAULT '2026-07-24';
DECLARE recent_end_date DATE DEFAULT '2026-09-07';

SELECT
  segments_date,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
WHERE segments_date BETWEEN recent_start_date AND recent_end_date
GROUP BY segments_date
ORDER BY segments_date;


-- ============================================================
-- QUERY 08: TARGET ROAS GAP SCENARIO
-- Current baseline values are calculated from the selected period.
-- These are directional scenarios, not guaranteed outcomes.
-- ============================================================
WITH baseline AS (
  SELECT
    SUM(metrics_cost_micros) / 1000000 AS current_spend,
    SUM(metrics_conversions_value) AS current_conversion_value
  FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
  WHERE segments_date BETWEEN '2026-08-02' AND '2026-08-31'
),
scenario AS (
  SELECT
    5.0 AS target_roas,
    current_spend,
    current_conversion_value,
    SAFE_DIVIDE(current_conversion_value, current_spend) AS current_roas
  FROM baseline
)
SELECT
  current_spend,
  current_conversion_value,
  current_roas,
  target_roas,
  target_roas - current_roas AS roas_gap,
  (current_spend * target_roas) - current_conversion_value
    AS additional_value_required_at_same_spend,
  SAFE_DIVIDE(current_conversion_value, target_roas)
    AS theoretical_spend_at_target_roas,
  current_spend - SAFE_DIVIDE(current_conversion_value, target_roas)
    AS theoretical_spend_reduction
FROM scenario;


-- ============================================================
-- QUERY 09: CAMPAIGN-LEVEL PERFORMANCE
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

SELECT
  campaign_id,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas,
  SAFE_DIVIDE(
    SUM(metrics_cost_micros) / 1000000,
    SUM(SUM(metrics_cost_micros) / 1000000) OVER ()
  ) AS spend_share,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(SUM(metrics_conversions_value)) OVER ()
  ) AS revenue_share
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
WHERE segments_date BETWEEN start_date AND end_date
GROUP BY campaign_id
ORDER BY total_spend DESC;


-- ============================================================
-- QUERY 10: LATEST CAMPAIGN DIMENSIONS
-- One latest snapshot is selected for each campaign.
-- ============================================================
WITH latest_campaigns AS (
  SELECT
    campaign_id,
    campaign_name,
    campaign_advertising_channel_type,
    campaign_advertising_channel_sub_type,
    campaign_status,
    campaign_serving_status,
    campaign_bidding_strategy_type,
    campaign_maximize_conversion_value_target_roas
  FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaign`
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY campaign_id
    ORDER BY _PARTITIONTIME DESC
  ) = 1
)
SELECT
  campaign_id,
  campaign_name,
  campaign_advertising_channel_type,
  campaign_advertising_channel_sub_type,
  campaign_status,
  campaign_serving_status,
  campaign_bidding_strategy_type,
  campaign_maximize_conversion_value_target_roas
FROM latest_campaigns
ORDER BY campaign_id;


-- ============================================================
-- QUERY 11: CHANNEL PERFORMANCE
-- Uses latest campaign dimensions for channel classification.
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

WITH latest_campaigns AS (
  SELECT
    campaign_id,
    campaign_advertising_channel_type,
    campaign_advertising_channel_sub_type
  FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaign`
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY campaign_id
    ORDER BY _PARTITIONTIME DESC
  ) = 1
)
SELECT
  COALESCE(
    c.campaign_advertising_channel_type,
    'UNKNOWN'
  ) AS channel_type,
  COALESCE(
    c.campaign_advertising_channel_sub_type,
    'UNKNOWN'
  ) AS channel_sub_type,
  SUM(s.metrics_cost_micros) / 1000000 AS total_spend,
  SUM(s.metrics_conversions_value) AS total_conversion_value,
  SUM(s.metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(s.metrics_conversions_value),
    SUM(s.metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats` s
LEFT JOIN latest_campaigns c
  ON s.campaign_id = c.campaign_id
WHERE s.segments_date BETWEEN start_date AND end_date
GROUP BY channel_type, channel_sub_type
ORDER BY total_spend DESC;


-- ============================================================
-- QUERY 12: CHANNEL AND DEVICE PERFORMANCE
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

WITH latest_campaigns AS (
  SELECT
    campaign_id,
    campaign_advertising_channel_type
  FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaign`
  QUALIFY ROW_NUMBER() OVER (
    PARTITION BY campaign_id
    ORDER BY _PARTITIONTIME DESC
  ) = 1
)
SELECT
  COALESCE(c.campaign_advertising_channel_type, 'UNKNOWN')
    AS channel_type,
  COALESCE(s.segments_device, 'UNKNOWN') AS device,
  SUM(s.metrics_cost_micros) / 1000000 AS total_spend,
  SUM(s.metrics_conversions_value) AS total_conversion_value,
  SUM(s.metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(s.metrics_conversions_value),
    SUM(s.metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats` s
LEFT JOIN latest_campaigns c
  ON s.campaign_id = c.campaign_id
WHERE s.segments_date BETWEEN start_date AND end_date
GROUP BY channel_type, device
ORDER BY total_spend DESC;


-- ============================================================
-- QUERY 13: CAMPAIGN + CATEGORY PERFORMANCE
-- Requires valid category and campaign/product join keys.
-- Validate grain before using the output for budget decisions.
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

SELECT
  campaign_id,
  segments_product_category_level1,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_ShoppingProductStats`
WHERE segments_date BETWEEN start_date AND end_date
GROUP BY campaign_id, segments_product_category_level1
ORDER BY total_spend DESC;


-- ============================================================
-- QUERY 14: SHOPPING PRODUCT STATS RECONCILIATION
-- This is intentionally separate from CampaignBasicStats.
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

SELECT
  'ShoppingProductStats' AS data_source,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_ShoppingProductStats`
WHERE segments_date BETWEEN start_date AND end_date;


-- ============================================================
-- QUERY 15: CAMPAIGN VS PRODUCT DATASET COMPARISON
-- Do not add these totals together.
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

SELECT
  'CampaignBasicStats' AS data_source,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
WHERE segments_date BETWEEN start_date AND end_date

UNION ALL

SELECT
  'ShoppingProductStats' AS data_source,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_ShoppingProductStats`
WHERE segments_date BETWEEN start_date AND end_date;


-- ============================================================
-- QUERY 16: CAMPAIGN SNAPSHOT GRAIN VALIDATION
-- Checks whether the selected dimensions produce duplicate groups.
-- ============================================================
SELECT
  campaign_id,
  campaign_base_campaign,
  segments_date,
  segments_device,
  segments_ad_network_type,
  segments_slot,
  COUNT(*) AS row_count
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
GROUP BY
  campaign_id,
  campaign_base_campaign,
  segments_date,
  segments_device,
  segments_ad_network_type,
  segments_slot
HAVING COUNT(*) > 1
ORDER BY row_count DESC;


-- ============================================================
-- QUERY 17: CAMPAIGN SNAPSHOT SETTING CHANGES
-- Snapshot-level changes are descriptive only and do not prove
-- that a setting change caused a performance change.
-- ============================================================
WITH snapshots AS (
  SELECT
    campaign_id,
    _PARTITIONTIME AS snapshot_time,
    campaign_budget_amount_micros,
    campaign_bidding_strategy,
    campaign_status,
    campaign_serving_status,
    campaign_maximize_conversion_value_target_roas,
    LAG(campaign_budget_amount_micros) OVER (
      PARTITION BY campaign_id
      ORDER BY _PARTITIONTIME
    ) AS previous_budget,
    LAG(campaign_bidding_strategy) OVER (
      PARTITION BY campaign_id
      ORDER BY _PARTITIONTIME
    ) AS previous_bidding_strategy,
    LAG(campaign_status) OVER (
      PARTITION BY campaign_id
      ORDER BY _PARTITIONTIME
    ) AS previous_status,
    LAG(campaign_serving_status) OVER (
      PARTITION BY campaign_id
      ORDER BY _PARTITIONTIME
    ) AS previous_serving_status,
    LAG(campaign_maximize_conversion_value_target_roas) OVER (
      PARTITION BY campaign_id
      ORDER BY _PARTITIONTIME
    ) AS previous_target_roas
  FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaign`
)
SELECT
  campaign_id,
  snapshot_time,
  previous_budget,
  campaign_budget_amount_micros AS current_budget,
  previous_bidding_strategy,
  campaign_bidding_strategy AS current_bidding_strategy,
  previous_status,
  campaign_status AS current_status,
  previous_serving_status,
  campaign_serving_status AS current_serving_status,
  previous_target_roas,
  campaign_maximize_conversion_value_target_roas AS current_target_roas
FROM snapshots
WHERE
  previous_budget IS DISTINCT FROM campaign_budget_amount_micros
  OR previous_bidding_strategy IS DISTINCT FROM campaign_bidding_strategy
  OR previous_status IS DISTINCT FROM campaign_status
  OR previous_serving_status IS DISTINCT FROM campaign_serving_status
  OR previous_target_roas IS DISTINCT FROM
      campaign_maximize_conversion_value_target_roas
ORDER BY campaign_id, snapshot_time;


-- ============================================================
-- QUERY 18: DAILY BASELINE VALIDATION BY WEEKDAY
-- Helps identify weekday-level variation without inferring causality.
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

SELECT
  EXTRACT(DAYOFWEEK FROM segments_date) AS day_of_week_number,
  FORMAT_DATE('%A', segments_date) AS day_of_week,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
WHERE segments_date BETWEEN start_date AND end_date
GROUP BY day_of_week_number, day_of_week
ORDER BY day_of_week_number;


-- ============================================================
-- ============================================================
-- QUERY 19: FEED SCHEMA VALIDATION / EVIDENCE GATE
-- ============================================================
-- The exact list_obj diagnostic field names were not validated in the
-- available execution record. Therefore, this submission does not claim
-- a quantified feed-issue aggregation.
--
-- Run this query first in BigQuery. Only after confirming the actual
-- diagnostic/status and snapshot/date fields should an issue-level
-- aggregation be added and used in the presentation.
-- ============================================================

SELECT
  column_name,
  data_type,
  is_nullable,
  ordinal_position
FROM `quantacusinterviewproject.interview_ayad.INFORMATION_SCHEMA.COLUMNS`
WHERE table_name = 'list_obj'
ORDER BY ordinal_position;


-- Supporting evidence rule:
-- Do not report feed disapproval counts, issue shares, or category-level
-- feed impact unless the confirmed list_obj fields and an executed
-- aggregation query are available. The presentation frames feed work
-- as a validation and remediation dependency, not as a quantified result.


-- QUERY 20: FINAL BASELINE OUTPUT FOR REPORTING
-- ============================================================
DECLARE start_date DATE DEFAULT '2026-08-02';
DECLARE end_date DATE DEFAULT '2026-08-31';

SELECT
  start_date AS analysis_start_date,
  end_date AS analysis_end_date,
  SUM(metrics_cost_micros) / 1000000 AS total_spend,
  SUM(metrics_conversions_value) AS total_conversion_value,
  SUM(metrics_conversions) AS total_conversions,
  SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS recalculated_roas,
  5.0 AS target_roas,
  5.0 - SAFE_DIVIDE(
    SUM(metrics_conversions_value),
    SUM(metrics_cost_micros) / 1000000
  ) AS roas_gap
FROM `quantacusinterviewproject.interview_ayad.p_ads_Campaignbasicstats`
WHERE segments_date BETWEEN start_date AND end_date;


-- ============================================================
-- END OF SQL SUBMISSION FILE
-- ============================================================
